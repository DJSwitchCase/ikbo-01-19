public class Main {
    public static void main(String[] args) {
        System.out.println(PhoneNumber.fix("+101234567890"));
        System.out.println(PhoneNumber.fix("81234567890"));

    }
}
