package practice11;

public interface Queue<E> {
    E element();
    E poll();
    E peek();
    Е remove();
    boolean offer(Е оbj);
    boolean add(E element);
}
