package practice10;

import java.util.Scanner;

public class Client {
    public Chair chair;

    public void sit(){
        System.out.println();
    }

    public void setChair(Chair chair){
        this.chair = chair;
    }
}

class Main {
    public static void main(String[] args) {

}
