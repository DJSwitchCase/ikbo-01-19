package practice10;

public class FunctionalChair implements Chair{
    public int sum (int a, int b){
        return a+b;
    }
}
