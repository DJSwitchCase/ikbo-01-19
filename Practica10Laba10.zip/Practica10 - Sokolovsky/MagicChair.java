package practice10;

public class MagicChair implements Chair {
    public void doMagic(){
    }
}
