package practice10;

public interface Chair {}