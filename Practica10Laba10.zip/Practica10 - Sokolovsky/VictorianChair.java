package practice10;

public class VictorianChair implements Chair{
    private int age;

    public VictorianChair(int age){
        this.age = age;
    }

    public int getAge() {
        return age;
    }
}
